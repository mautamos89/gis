import earthaccess, warnings, earthpy.spatial as es, earthpy.plot as ep, numpy as np
import os, geopandas as gpd, rasterio as rio, matplotlib.pyplot as plt, re, matplotlib.patches as mpatches
from time import strftime
from shapely.geometry import box
from matplotlib.colors import ListedColormap
# Ignorar warnings
warnings.simplefilter(action='ignore', category=FutureWarning) # Ignorar warnings de earthaccess
warnings.filterwarnings('ignore', message=".*'partition' will ignore the 'mask'.*") # Ignorar advertencia específica de Numpy y MaskedArrays

def buscar_imagen(coleccion, coordenadas, fecha_inicio, fecha_final, limite):
    """Busca las imágenes en un rango de fechas y coordenadas """
    # Inicio de script
    print("\nBúsqueda de imágenes iniciada: " + strftime("%Y-%m-%d %H:%M:%S"))
    # Autenticación en consola
    earthaccess.login(strategy="interactive")
    print("Usuario autenticado")

    # Búsqueda de granulares armonizados HLS ['HLSS30' = Sentinel-2 | 'HLSL30' = LandSat-8]
    results = earthaccess.search_data(
        short_name=coleccion,
        cloud_hosted=True,
        bounding_box=(coordenadas), # (lon_min, lat_min, lon_max, lat_max)
        temporal=(fecha_inicio, fecha_final),
        count=limite # Limitar el número de resultados entre fechas
    )
    print("Parámetros de consulta establecidos\n")
    print("Lista de imágenes encontradas")

    # Imprimir en pantalla el resultado
    for number, granule in enumerate(results,start=1):
            full_date = granule['umm']['TemporalExtent']['RangeDateTime']['BeginningDateTime'] # Fecha y hora completa
            date_only = full_date[:10] # Solo la fecha
            print(f"{number} | ID: {granule['meta']['native-id']} | Fecha: {date_only}")
    
    # Fin de script
    print("Búsqueda de imágenes finalizada: " + strftime("%Y-%m-%d %H:%M:%S"))
    return results

def descargar_imagen(lista_descarga):
    """Descarga la lista de imágenes filtrando la primera y la última"""
    # Inicio de script
    print("\nDescarga de imágenes iniciada: " + strftime("%Y-%m-%d %H:%M:%S"))

    # Descargar los archivos
    if len(lista_descarga) > 1:
        subset_to_download = [lista_descarga[0], lista_descarga[-1]] # Seleccionar el primer y último registro
    else:
        subset_to_download = lista_descarga # Todos

    # Descargar los archivos
    print(f"Descargando imágenes: {len(subset_to_download)}")
    files = earthaccess.download(subset_to_download, local_path="./salida/1_datos_hls")
    
    # Fin de script
    print("Descarga de imágenes finalizada: " + strftime("%Y-%m-%d %H:%M:%S"))
    return files

# Recortar bandas
def recortar_banda(archivo_entrada, area_recorte):
    """Recorta las bandas espectrales descargadas para un área definida"""
    # Inicio de script
    print("\nRecorte de bandas espectrales iniciado: " + strftime("%Y-%m-%d %H:%M:%S"))
    
    # Listar archivos Tif
    rutas_hls = [str(f) for f in archivo_entrada if str(f).endswith('.tif')] # Filtrar por extensión Tif
    print(f"Número de archivos Tif a recortar: {len(rutas_hls)}")

    # Definir geometría de recorte
    geom_recorte = box(*area_recorte)
    gdf_area = gpd.GeoDataFrame({'geometry': [geom_recorte]}, crs="EPSG:4326") # Crear gdf reproyectado

    # Obtener CRS del rster y reproyectar
    with rio.open(rutas_hls[0]) as src:
        perfil_raster = src.profile
        area_reproyectado = gdf_area.to_crs(perfil_raster["crs"])
    print("Geometría definida y proyectada para recorte")

    # Crear carpeta de salida
    directorio_recorte = os.path.join("./salida/2_recorte")
    os.makedirs(directorio_recorte, exist_ok=True)

    # Aplicar el recorte y guardar
    rutas_recortadas = es.crop_all(
        rutas_hls, directorio_recorte, area_reproyectado, overwrite=True
    )
    rutas_recortadas.sort() 

    # Fin de script
    print("Recorte de bandas espectrales finalizado: " + strftime("%Y-%m-%d %H:%M:%S"))
    return rutas_recortadas

def crear_stack_plot(recortes, combinacion):
    """Crea un stack y plot de las imágenes descargadas"""
    # Inicio de script
    print("\nStack y plot de imágenes iniciado: " + strftime("%Y-%m-%d %H:%M:%S"))

    # Crear carpeta para los plots si no existe
    directorio_plots = os.path.join("./salida/3_plot")
    os.makedirs(directorio_plots, exist_ok=True)

    # Expresión para filtrar solo bandas espectrales (B01, etc)
    patron_bandas = re.compile(r'\.B[0-9]{2}')
    # Extraer ID de escenas
    ids_imagenes = sorted(list(set([os.path.basename(f).split('.B')[0] for f in recortes])))

    # Iterar sobre las escenas por ID
    i = 1
    for img_id in ids_imagenes:
        # Seleccionar archivos correspondiente a bandas espectral por escena
        bandas_solo = [f for f in recortes if img_id in f and patron_bandas.search(f)]
        bandas_solo.sort()
        # Verificar el contenido del stack
        if len(bandas_solo) < 12: 
            continue

        # Crear el stack
        print(f"Creando plot para: {img_id} | # de bandas: {len(bandas_solo)}")
        matriz_recortada, _ = es.stack(bandas_solo, nodata=-9999)

        # Configurar el plot
        fig, ax = plt.subplots(figsize=(12, 12))
        ep.plot_rgb(
            matriz_recortada, 
            rgb=(combinacion),
            stretch=True, # Ajustar el contraste
            ax=ax, 
            title=f"Imagen HLS: {img_id}\nFalso color mejorado (7-4-3)"
        )
        
        # Guardar el plot en carpeta
        nombre_archivo_plot = os.path.join(directorio_plots, f"{i}_plot_{img_id}.png")
        plt.savefig(nombre_archivo_plot, bbox_inches='tight', dpi=150)
        plt.close(fig) # Cerrar el plot
        i += 1

    # Fin de script
    print("Stack y plot de imágenes finalizado: " + strftime("%Y-%m-%d %H:%M:%S"))
    return matriz_recortada, img_id

def calcular_nbr(recortes):
    """Calcula índice de área quemada (NBR) para cada escena descargada"""
    print("\nCálculo de NBR iniciado: " + strftime("%Y-%m-%d %H:%M:%S"))

    # Crear carpeta para los plots si no existe
    directorio_plots = os.path.join("./salida/3_plot")
    os.makedirs(directorio_plots, exist_ok=True)

    # Filtrar solo las bandas par el índice
    patron_nbr = re.compile(r'\.(B08|B12)')
    ids_imagenes = sorted(list(set([os.path.basename(f).split('.B')[0] for f in recortes]))) # Extraer ID de escenas para bandas espectrales
    
    # Lista para almacenar los arrays
    resultados_nbr = []
    # Iterar sobre las escenas por ID
    i = 3 # Iniciar contador
    for img_id in ids_imagenes:
        bandas_nbr = [f for f in recortes if img_id in f and patron_nbr.search(f)]
        bandas_nbr.sort() 
        
        # Verificar el contenido del stack
        if len(bandas_nbr) < 2: continue

        # Crear el stack
        print(f"Procesando NBR para: {img_id} | # de bandas: {len(bandas_nbr)}")
        matriz_nbr, _ = es.stack(bandas_nbr, nodata=-9999)
        
        # Cálculo NBR
        nbr = es.normalized_diff(matriz_nbr[0], matriz_nbr[1])
        resultados_nbr.append(nbr) # Adjuntar a la lista

        # Crear plot NBR por escena
        fig, ax = plt.subplots(figsize=(14, 14))
        ep.plot_bands(nbr, cmap='RdYlGn', vmin=-1, vmax=1, ax=ax, title=f"NBR: {img_id}")
        plt.savefig(os.path.join(directorio_plots, f"{i}_nbr_{img_id}.png"), bbox_inches='tight')
        plt.close(fig)
        i += 1
    
    # Fin de script
    print("Cálculo de NBR finalizado: " + strftime("%Y-%m-%d %H:%M:%S"))
    return resultados_nbr

def calcular_dnbr(lista_nbr):
    """Calcula dNBR y genera un plot clasificado por niveles de severidad"""
    print("\nCálculo de dNBR iniciado: " + strftime("%Y-%m-%d %H:%M:%S"))

    # Verificar el contenido de la lista
    if len(lista_nbr) < 2:
        print("Se requieren al menos dos fechas (pre y post) para dNBR.")
        return

    # Calcular dNBR (pre - post)
    dnbr = lista_nbr[0] - lista_nbr[-1]

    # Definir los límites de los rangos (bins)
    bins = np.array([-0.25, -0.1, 0.1, 0.27, 0.44])
    
    # Clasificar los datos
    dnbr_clasificado = np.digitize(dnbr, bins)
    print("dNBR calculado y clasificado")

    # Definir colores y etiquetas
    colores = ["#006400", "#7cfc00", "#ffff00", "#ffa500", "#ff4500", "#8b0000"]
    etiquetas = [
        "Alto crecimiento post-fuego (< -0.25)",
        "Bajo crecimiento post-fuego (-0.25 a -0.1)",
        "Zonas estables o sin quemar (-0.1 a 0.1)",
        "Gravedad baja (0.1 a 0.27)",
        "Gravedad moderada-baja (0.27 a 0.44)",
        "Gravedad moderada-alta (> 0.44)"
    ]
    cmap_propio = ListedColormap(colores) # Emplear lisda de colores

    # Crear el Plot
    fig, ax = plt.subplots(figsize=(14, 14))
    
    # Mostrar la matriz clasificada
    ep.plot_bands(dnbr_clasificado, 
                       cmap=cmap_propio, 
                       ax=ax, 
                       title="Clasificación de Severidad del Incendio (dNBR)",
                       cbar=False)
    
    # Crear parches para leyenda
    parches = [mpatches.Patch(color=colores[i], label=etiquetas[i]) for i in range(len(etiquetas))]
    
    # Añadir leyenda
    ax.legend(handles=parches, 
              bbox_to_anchor=(1.05, 1), 
              loc='upper left', 
              borderaxespad=0.,
              title="Niveles de Severidad")

    # Guardar resultado
    ruta_salida = os.path.join("./salida/3_plot", "5_dnbr.png")
    plt.savefig(ruta_salida, bbox_inches='tight', dpi=150)
    plt.close(fig)
    
    # Fin de script
    print("Cálculo de dNBR finalizado: " + strftime("%Y-%m-%d %H:%M:%S"))
    return dnbr_clasificado
