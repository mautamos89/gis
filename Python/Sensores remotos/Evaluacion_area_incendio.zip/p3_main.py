# coding=utf-8
# Título: Práctica 3-Evaluación de un incendio empleando imágenes HSL Sentinel-2
# Requerimientos: Python 3x
# Librerías: earthaccess, earthpy, numy, rasterio, matplotlib, geopandas, time, os
# Autor: Mauricio Tabares Mosquera
# Fecha: 2026-04-13

# Importar librerías y funciones
from app.function import buscar_imagen, descargar_imagen, recortar_banda, crear_stack_plot, calcular_nbr, calcular_dnbr
from time import strftime

# Inicio de script
print("\nScript iniciado: ".upper() + strftime("%Y-%m-%d %H:%M:%S"))

# Variables de usuario
datos_coleccion= "HLSS30" # 'HLSS30' = Sentinel-2 | 'HLSL30' = LandSat-8
area_interes = -74.627895, 4.252862, -74.582148, 4.286329 # Municipio de Nilo, Cundinamarca, Colombia
inicio = "2024-08-14" # Rango inferior
final = "2024-10-10" # Rango superior
numero_registros = 15 # Límite de registros
combinacion_plot = 7, 4, 3 # Combinación RGB

# Ejecutar funciones

# Buscar imágenes
imagen = buscar_imagen(datos_coleccion, area_interes, inicio, final, numero_registros)
# Descargar imágenes
archivo_descarga = descargar_imagen(imagen)
# Recortar imágenes
archivo_recortado = recortar_banda(archivo_descarga, area_interes)
# Crear stack y plot
stack_plot = crear_stack_plot(archivo_recortado, combinacion_plot)
# Calcular NBR
lista_nbr = calcular_nbr(archivo_recortado)
# Calcular dNBR usando el NBR por imagen
calcular_dnbr(lista_nbr)

# Fin script
print("\nScript terminado: ".upper() + strftime("%Y-%m-%d %H:%M:%S"))